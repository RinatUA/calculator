# паркування маркерів          
from modules.windows import *
from modules.labels import *
from modules.allButton import *
from modules.allLayouts import main_VLayout
from modules.clicked_connect import *
from modules.settingsbutton import *
from modules.symbol_operation import *
#
sort_button()
show_buttons()
#
win.show()
#
app.exec_() 
   