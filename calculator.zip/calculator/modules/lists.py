list_buttons = []
#
list_number_button = list()
#
list_symbol_button = list()
#
list_name_symbol = ["AC", "+/-", "%", "÷", "x", "-", "+", "=", ","]
# 
list_input = []
#
list_arithmetic_operation = ["+", "-", "x", "÷", "%"]