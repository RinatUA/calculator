from PyQt5.QtGui import QFont

font1 = QFont("Times New Roman", 32)
